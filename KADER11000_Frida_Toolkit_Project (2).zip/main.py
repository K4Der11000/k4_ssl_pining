# Main logic for Frida control
print('Starting Frida Toolkit...')