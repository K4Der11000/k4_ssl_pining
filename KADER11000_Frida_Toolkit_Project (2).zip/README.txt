How to run:
1. Install APK
2. Run this server
3. Connect your device
4. Inject scripts