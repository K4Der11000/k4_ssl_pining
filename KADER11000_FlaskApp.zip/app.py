
from flask import Flask, render_template, request, redirect, url_for, session
import os

app = Flask(__name__)
app.secret_key = 'kader11000'

@app.route('/')
def home():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST' and request.form['password'] == 'kader11000':
        session['logged_in'] = True
        return redirect(url_for('home'))
    return '''
        <form method="post">
            <h2 style="color:white;">Enter Password</h2>
            <input type="password" name="password">
            <input type="submit" value="Login">
        </form>
    '''

@app.route('/logout')
def logout():
    session['logged_in'] = False
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
