1. Install Python 3
2. Run: pip install -r requirements.txt
3. Start: python3 app.py
Password: kader11000